This is the manual for the HPE Cloud Volumes Backup service client.

Along with this manual, you should also have the following in your ZIP file:

- The secure client binary.
- A YAML configuration file for the client.
- A certificate for use by the client.
- The private key for the certificate.
- The CA for the certificate.
- A license file.

The client uses these files to forward traffic to the HPE Cloud Volumes Backup service.

Requirements
------------

To run the secure client, the following requirements must be met.

- Any Linux OS running on a physical or virtual machine.
- 4 CPU cores, 2.0GHz (minimum)
- 8GB RAM (minimum)

If multiple client processes are being run on the same machine, ensure that each instance has a
dedicated IP address. Re-use of IP addresses between clients is not supported and will cause
problems during backups. A secure client may use multiple IP addresses if desired for cases when
the secure client needs to be accessible from multiple locations.

Also ensure that memory and CPU resources are increased if running multiple client on the same
machine and that configuration files, certificates and private keys are not re-used between
different clients. To avoid confusion, it is recommended to store each secure client and associated
files in separate folders each with a meaningful name, such as the name of the backup store.

Setup
-----

If you have already downloaded and extracted this file, skip to step 3.

1. Download the ZIP file from the HPE Cloud Volumes Backup site.

2. Extract the following files from the ZIP:

    - This manual.
    - The client binary.
    - The client configuration file.
    - A certificate file.
    - A private key file.
    - A CA file.
    - A license file.

3. Create a new user to run the secure client. The client should not be run as the root user. This
   can be done by running "sudo useradd secureclient".

4. Ensure the files have the following file permissions set. To do this, run "sudo chmod MODE FILE",
   where "FILE" is the path to the file being altered.

    - Client binary: 755
    - Client configuration file: 644
    - Client certificate: 644
    - CA: 644
    - Private key: 600

5. Using "chown", change the ownership of the following files to the user created in step 3. To do
   this, run "sudo chown secureclient:secureclient FILE" where "FILE" is the path to the file being
   altered.

    - Client binary
    - Client configuration file
    - Client certificate
    - CA
    - Private key

6. Place the client binary, configuration, certificate, CA and private key in a dedicated folder
   owned by the user created in step 3. To do this, run "sudo mkdir -p /opt/cloudvolumes", followed
   by "sudo chown -R secureclient:secureclient /opt/cloudvolumes".

7. Ensure ports 9386, 9387 and 9388 are open in your firewall using a tool such as "nmap".

The client can be run as using an init system, such as systemd. If using an init system, ensure
that the process will be restarted on exit. The below example systemd service can be created as
"/etc/systemd/system/secure-client.service".

    [Unit]
    Description=HPE CloudVolumes Backup service client
    After=network.target

    [Service]
    User=secureclient
    Type=exec
    ExecStart=/opt/cloudvolumes/secure_client --config /opt/cloudvolumes/secure_client_config.yaml
    Restart=always
    RestartSec=10s
    LimitNOFILE=40000

    [Install]
    WantedBy=multi-user.target

In the above example, a dedicated directory owned by the "secureclient" user has been created as
"/opt/cloudvolumes". This folder contains the client binary, configuration file, certificate,
private key and CA. In this case, the logs output by the client will be collected by systemd and
viewable using "sudo journalctl -u secure-client.service"

If you are not using an init system, advice on how to manage logs is covered in the usage section.

Configuration
-------------

The YAML configuration file contains the following properties. These may need to be modified when
the client is being run via an init system.

- ca: The path to the CA file.
- cert: The path to the certificate file.
- key: The path to the private key file.

These paths can either be absolute, or relative to the location the client is being executed from.

It also contains the addresses for the secure client to listen on for incoming connections from
your backup application. These will generally be "0.0.0.0:PORT" and should only be modified if
multiple secure client instances are running on the same machine as described in the setup section.

- source1: The address and port to listen on for StoreOnce Catalyst command sessions.
- source2: The address and port to listen on for StoreOnce Catalyst data sessions.

Finally, it contains, the target addresses for the secure client to send to for connectivity with
your backup store. These should never need to be modified, but are listed here for completeness.

- target1: The address and port to send traffic for StoreOnce Catalyst command sessions.
- target2: The address and port to send traffic for StoreOnce Catalyst data sessions.

Usage
-----

If you are using an init system, the client can be started using the usual commands. For the
example systemd configuration above, and assuming it has been named "secure-client.service" this
will be:

    $ sudo systemctl enable secure-client
    $ sudo systemctl start secure-client

If you are not using an init system, navigate to the directory containing the client and execute it
as the user created to run the client:

    $ sudo su secureclient
    $ ./secure_client

To ensure that logs do not fill up the machine running the secure client, it is advised to make use
of the "--log" option and use logrotate to ensure that the logs do not fill up the machine it is
running on. For example:

    $ ./secure_client --log /var/log/cloudvolumes/secure_client.log

This requires that "/var/log/cloudvolumes" is a folder owned by the "secureclient" user. To add log
rotation, create the following as "/etc/logrotate.d/secure_client":

    /var/log/cloudvolumes/secure_client.log {
        rotate 4
        weekly
        compress
        missingok
        notifempty
    }

Configuring your ISV Backup Application
---------------------------------------

After you have set up and have started the Secure Client, complete the following steps to configure
your ISV backup application to connect with HPE CV Backup.

1. Log into your ISV backup application.

2. Follow the process in your backup application to add an HPE StoreOnce appliance as a backup
    store.

    - When prompted for the appliance address or IP, enter the Secure Client IP or address.
    - When prompted for credentials, enter the User ID and password that you received when you
      created your HPE CV Backup Store.

Certificate Renewal
-------------------

The TTL on the certificate and private key provided in the ZIP file is 90 days. After 30 days, the
client will attempt to renew these, storing the old files under "NAME.bak", where "NAME" is the
original name of the certificate or private key. The CA is not changed by the renewal process.

Assuming the certificates are eligible for renewal, the renewal will be performed on start up and
every 24 hours after. If the certificates have expired, automatic renewal will not be possible.
They will need to be reissued from the HPE Cloud Volumes Backup site (https://cloudvolumes.hpe.com)
instead.

If certificate renewal fails, check that the file permissions and owner for the certificate and
private key have been set correctly as detailed in the setup section. If it is suspected that the
certificate has expired, this can be verified using "openssl" as follows:

    $ openssl x509 -in NAME.crt -text -noout

Where "NAME.crt" is the path to the certificate file. The expiry of the certificate can be found
under the validity section as demonstrated below:

    Validity
        Not Before: Mar 20 14:45:26 2020 GMT
        Not After : Jun 18 14:45:55 2020 GMT

If the server is within its validity period, also ensure the date and time are correct on your
machine, using the "date" command. It is recommended to use an NTP client to avoid issues with
incorrect time on your machine. Most Linux distributions have "ntpd" available for this, although
newer distributions may come with "chronyd" instead.

If there is a concern that the wrong certificate is being used, the common name (CN) may be
verified using the same "openssl" command as above. The CN will be within the subject field in the
format "<prefix>.<store-name>.<store-id>.<suffix>" The value of "store-name" should match the name
of the backup store the secure client is used for.

Upgrading
---------

As new versions become available, the client will attempt to upgrade itself to that version. The
previous version is stored as "NAME.bak", where "NAME" is the original name of the client binary.
Updates are checked for on start up and every 24 hours after and are downloaded from the HPE Cloud
Volumes service.

If upgrading fails, check that the owner of the client has been set correctly as detailed in the
setup section.